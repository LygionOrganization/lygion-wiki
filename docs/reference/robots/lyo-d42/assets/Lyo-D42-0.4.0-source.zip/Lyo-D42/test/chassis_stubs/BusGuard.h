#pragma once
struct BusGuard{};
