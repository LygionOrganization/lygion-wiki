#include "Config.h"
#include "jointsCtrl.h"
#include "BusGuard.h"

void JointsCtrl::init(int baud) {
    BusGuard busGuard;
    baudrate = baud;
#ifndef TTL_ADAPTER_MACHINE
    Serial1.begin(baud, SERIAL_8N1, BUS_SERVO_RX, BUS_SERVO_TX);
    sc.pSerial = &Serial1;
    smst.pSerial = &Serial1;
    hl.pSerial = &Serial1;
    node.pSerial = &Serial1;
    sc.IOTimeOut=15; smst.IOTimeOut=15; hl.IOTimeOut=15; node.IOTimeOut=15;
#else
    Serial0.begin(500000);
    sc.pSerial = &Serial0;
    smst.pSerial = &Serial0;
    hl.pSerial = &Serial0;
#endif

#ifdef USE_HUB_MOTORS
    gqdmd.begin(&Serial1);
    gqdmd.setTxEnd_T32(500000);
    gqdmd.setTimeOut(2);
#endif

    while(!Serial1) {}
}

void JointsCtrl::setBaudRate(int baud) {
    BusGuard busGuard;
    baudrate = baud;
    Serial1.updateBaudRate(baud);

}

bool JointsCtrl::setJointType(u_int8_t type) {
    BusGuard busGuard;
    switch (type) {
        case JOINT_TYPE_SC:
            jointType = type;
            return true;
            break;
        case JOINT_TYPE_SMST:
            jointType = type;
            return true;
            break;
        case JOINT_TYPE_HL:
            jointType = type;
            return true;
            break;
    } 
    return false;
}

bool JointsCtrl::setEncoderStepRange(u_int16_t steps, double angle) {
    BusGuard busGuard;
    if (steps < 512) {
        return false;
    }
    if (angle < 90 || angle > 360) {
        return false;
    }
    jointSteps = steps;
    middleSteps = round(jointSteps/2 - 1);
    jointRangeAngle = angle;
    jointRangeRad = jointRangeAngle * M_PI / 180.0;

    for(int i = 0; i < JOINTS_NUM; i++) {
        jointsFeedbackPos[i] = middleSteps; // or any other default value
        jointsCurrentPos[i] = middleSteps; // or any other default value
        jointsGoalPos[i] = middleSteps; // or any other default value
        jointsLastPos[i] = middleSteps; // or any other default value
    }

    return true;
}

int* JointsCtrl::singleFeedBack(u_int8_t id) {
    BusGuard busGuard;
    // Get feedback from servo
    // [0]ping status
    // [1]position
    // [2]speed
    // [3]load
    // [4]voltage
    // [5]temperature
    // [6]moving
    // [7]current

    static int feedback[SERVO_FEEDBACK_NUM];
    switch (jointType) {
        case JOINT_TYPE_SC:
            sc.FeedBack(id);
            if (sc.getLastError()) {
                feedback[FB_PING] = -1;
                break;
            }
            feedback[FB_PING] = 1;
            feedback[FB_POS] = sc.ReadPos(-1);
            feedback[FB_SPD] = sc.ReadSpeed(-1);
            feedback[FB_LOAD] = sc.ReadLoad(-1);
            feedback[FB_VOLT] = sc.ReadVoltage(-1);
            feedback[FB_TEMP] = sc.ReadTemper(-1);
            feedback[FB_MOVE] = sc.ReadMove(-1);
            feedback[FB_CURT] = sc.ReadCurrent(-1);
            break;
        case JOINT_TYPE_SMST:
            smst.FeedBack(id);
            if (smst.getLastError()) {
                feedback[FB_PING] = -1;
                break;
            }
            feedback[FB_PING] = 1;
            feedback[FB_POS] = smst.ReadPos(-1);
            feedback[FB_SPD] = smst.ReadSpeed(-1);
            feedback[FB_LOAD] = smst.ReadLoad(-1);
            feedback[FB_VOLT] = smst.ReadVoltage(-1);
            feedback[FB_TEMP] = smst.ReadTemper(-1);
            feedback[FB_MOVE] = smst.ReadMove(-1);
            feedback[FB_CURT] = smst.ReadCurrent(-1);
            break;
        case JOINT_TYPE_HL:
            hl.FeedBack(id);
            if (hl.getLastError()) {
                feedback[FB_PING] = -1;
                break;
            }
            feedback[FB_PING] = 1;
            feedback[FB_POS] = hl.ReadPos(-1);
            feedback[FB_SPD] = hl.ReadSpeed(-1);
            feedback[FB_LOAD] = hl.ReadLoad(-1);
            feedback[FB_VOLT] = hl.ReadVoltage(-1);
            feedback[FB_TEMP] = hl.ReadTemper(-1);
            feedback[FB_MOVE] = hl.ReadMove(-1);
            feedback[FB_CURT] = hl.ReadCurrent(-1);
            break;
    }

    return feedback;
}

int* JointsCtrl::feedbackSTSM(u_int8_t id) {
    BusGuard busGuard;
    // Get feedback from servo
    // [0]ping status
    // [1]position
    // [2]speed
    // [3]load
    // [4]voltage
    // [5]temperature
    // [6]moving
    // [7]current

    static int feedback[SERVO_FEEDBACK_NUM];
    smst.FeedBack(id);
    if (smst.getLastError()) {
        feedback[FB_PING] = -1;
        return feedback;
    }
    feedback[FB_PING] = 1;
    feedback[FB_POS] = smst.ReadPos(-1);
    feedback[FB_SPD] = smst.ReadSpeed(-1);
    feedback[FB_LOAD] = smst.ReadLoad(-1);
    feedback[FB_VOLT] = smst.ReadVoltage(-1);
    feedback[FB_TEMP] = smst.ReadTemper(-1);
    feedback[FB_MOVE] = smst.ReadMove(-1);
    feedback[FB_CURT] = smst.ReadCurrent(-1);

    return feedback;
}

int* JointsCtrl::feedbackHL(u_int8_t id) {
    BusGuard busGuard;
    // Get feedback from servo
    // [0]ping status
    // [1]position
    // [2]speed
    // [3]load
    // [4]voltage
    // [5]temperature
    // [6]moving
    // [7]current

    static int feedback[SERVO_FEEDBACK_NUM];
    hl.FeedBack(id);
    if (hl.getLastError()) {
        feedback[FB_PING] = -1;
        return feedback;
    }
    feedback[FB_PING] = 1;
    feedback[FB_POS] = hl.ReadPos(-1);
    feedback[FB_SPD] = hl.ReadSpeed(-1);
    feedback[FB_LOAD] = hl.ReadLoad(-1);
    feedback[FB_VOLT] = hl.ReadVoltage(-1);
    feedback[FB_TEMP] = hl.ReadTemper(-1);
    feedback[FB_MOVE] = hl.ReadMove(-1);
    feedback[FB_CURT] = hl.ReadCurrent(-1);

    return feedback;
}

int* JointsCtrl::feedbackSC(u_int8_t id) {
    BusGuard busGuard;
    // Get feedback from servo
    // [0]ping status
    // [1]position
    // [2]speed
    // [3]load
    // [4]voltage
    // [5]temperature
    // [6]moving
    // [7]current

    static int feedback[SERVO_FEEDBACK_NUM];
    sc.FeedBack(id);
    if (sc.getLastError()) {
        feedback[FB_PING] = -1;
        return feedback;
    }
    feedback[FB_PING] = 1;
    feedback[FB_POS] = sc.ReadPos(-1);
    feedback[FB_SPD] = sc.ReadSpeed(-1);
    feedback[FB_LOAD] = sc.ReadLoad(-1);
    feedback[FB_VOLT] = sc.ReadVoltage(-1);
    feedback[FB_TEMP] = sc.ReadTemper(-1);
    feedback[FB_MOVE] = sc.ReadMove(-1);
    feedback[FB_CURT] = sc.ReadCurrent(-1);

    return feedback;
}


bool JointsCtrl::pingSTSM(u_int8_t id) {
    BusGuard busGuard;
    smst.Ping(id);
    if (smst.getLastError()) {
        return false;
    } else {
        return true;
    }
}

bool JointsCtrl::pingHL(u_int8_t id) {
    BusGuard busGuard;
    hl.Ping(id);
    if (hl.getLastError()) {
        return false;
    } else {
        return true;
    }
}

bool JointsCtrl::pingSC(u_int8_t id) {
    BusGuard busGuard;
    sc.Ping(id);
    if (sc.getLastError()) {
        return false;
    } else {
        return true;
    }
}

bool JointsCtrl::ping(u_int8_t id) {
    BusGuard busGuard;
    switch (jointType) {
        case JOINT_TYPE_SC:
            pingSC(id);
            break;
        case JOINT_TYPE_SMST:
            pingSTSM(id);
            break;
        case JOINT_TYPE_HL:
            pingHL(id);
            break;
    }
    return false;
}


bool JointsCtrl::changeIDSTSM(u_int8_t old_id, u_int8_t new_id) {
    BusGuard busGuard;
    if (old_id > 253 || new_id > 253 || old_id == new_id) return false;
    if (smst.Ping(new_id) == new_id || smst.Ping(old_id) != old_id) return false;
    if (smst.unLockEprom(old_id) != 1 || smst.getState() != 0) return false;
    smst.writeByte(old_id, SMS_STS_ID, new_id);
    if (smst.Ping(new_id) != new_id) { smst.LockEprom(old_id); return false; }
    return smst.LockEprom(new_id) == 1 && smst.getState() == 0;
}

bool JointsCtrl::changeIDHL(u_int8_t old_id, u_int8_t new_id) {
    BusGuard busGuard;
    if (old_id > 253 || new_id > 253 || old_id == new_id) return false;
    if (hl.Ping(new_id) == new_id || hl.Ping(old_id) != old_id) return false;
    if (hl.unLockEprom(old_id) != 1 || hl.getState() != 0) return false;
    hl.writeByte(old_id, SMS_STS_ID, new_id);
    if (hl.Ping(new_id) != new_id) { hl.LockEprom(old_id); return false; }
    return hl.LockEprom(new_id) == 1 && hl.getState() == 0;
}

bool JointsCtrl::changeIDSC(u_int8_t old_id, u_int8_t new_id) {
    BusGuard busGuard;
    if (old_id > 253 || new_id > 253 || old_id == new_id) return false;
    if (sc.Ping(new_id) == new_id || sc.Ping(old_id) != old_id) return false;
    if (sc.unLockEprom(old_id) != 1 || sc.getState() != 0) return false;
    sc.writeByte(old_id, SCSCL_ID, new_id);
    if (sc.Ping(new_id) != new_id) { sc.LockEprom(old_id); return false; }
    return sc.LockEprom(new_id) == 1 && sc.getState() == 0;
}

bool JointsCtrl::changeID(u_int8_t old_id, u_int8_t new_id) {
    BusGuard busGuard;
    switch (jointType) {
        case JOINT_TYPE_SC:
            if (!pingSC(old_id)) {
                return false;
            } else {
                changeIDSC(old_id, new_id);
                return true;
            }
            break;
        case JOINT_TYPE_SMST:
            if (!pingSTSM(old_id)) {
                return false;
            } else {
                changeIDSTSM(old_id, new_id);
                return true;
            }
            break;
        case JOINT_TYPE_HL:
            if (!pingHL(old_id)) {
                return false;
            } else {
                changeIDHL(old_id, new_id);
                return true;
            }
            break;
    }
    return false;
}


bool JointsCtrl::setMiddleSTSM(u_int8_t id) {
    BusGuard busGuard;
    if (!pingSTSM(id)) {
        return false;
    } else {
        smst.CalibrationOfs(id);
        return true;
    }
}

bool JointsCtrl::setMiddleHL(u_int8_t id) {
    BusGuard busGuard;
    if (!ping(id)) {
        return false;
    } else {
        hl.CalibrationOfs(id);
        return true;
    }
}

bool JointsCtrl::setMiddle(u_int8_t id) {
    BusGuard busGuard;
    switch (jointType) {
        case JOINT_TYPE_SC:
            return false;
            break;
        case JOINT_TYPE_SMST:
            return setMiddleSTSM(id);
            break;
        case JOINT_TYPE_HL:
            return setMiddleHL(id);
            break;
    }
    return false;
}


void JointsCtrl::moveMiddle(u_int8_t id) {
    BusGuard busGuard;
    switch (jointType) {
        case JOINT_TYPE_SC:
            sc.WritePos(id, middleSteps, 0, 300);
            break;
        case JOINT_TYPE_SMST:
            smst.WritePosEx(id, middleSteps, 300, 50);
            break;
        case JOINT_TYPE_HL:
            hl.WritePosEx(id, middleSteps, 10, 50, 500);
            break;
    }
}


void JointsCtrl::torqueLockSTSM(u_int8_t id, bool state) {
    BusGuard busGuard;
    if (state) {
        smst.EnableTorque(id, 1);
    } else {
        smst.EnableTorque(id, 0);
    }
}

void JointsCtrl::torqueLockHL(u_int8_t id, bool state) {
    BusGuard busGuard;
    if (state) {
        hl.EnableTorque(id, 1);
    } else {
        hl.EnableTorque(id, 0);
    }
}

void JointsCtrl::torqueLockSC(u_int8_t id, bool state) {
    BusGuard busGuard;
    if (state) {
        sc.EnableTorque(id, 1);
    } else {
        sc.EnableTorque(id, 0);
    }
}

void JointsCtrl::torqueLock(u_int8_t id, bool state) {
    BusGuard busGuard;
    switch (jointType) {
        case JOINT_TYPE_SC:
            torqueLockSC(id, state);
            break;
        case JOINT_TYPE_SMST:
            torqueLockSTSM(id, state);
            break;
        case JOINT_TYPE_HL:
            torqueLockHL(id, state);
            break;
    }
}

void JointsCtrl::stepsCtrlSC(u_int8_t id, int pos, int time, int speed, bool move_trigger) {
    BusGuard busGuard;
    if (move_trigger) {
        sc.WritePos(id, pos, time, speed);
    } else {
        sc.RegWritePos(id, pos, time, speed);
    }
}

void JointsCtrl::stepsCtrlSMST(u_int8_t id, int pos, int speed, int acc, bool move_trigger) {
    BusGuard busGuard;
    if (move_trigger) {
        smst.WritePosEx(id, pos, speed, acc);
    } else {
        smst.RegWritePosEx(id, pos, speed, acc);
    }
}

void JointsCtrl::stepsCtrlHL(u_int8_t id, int pos, int speed, int acc, int currt_limit, bool move_trigger) {
    BusGuard busGuard;
    if (move_trigger) {
        hl.WritePosEx(id, pos, speed, acc, currt_limit);
    } else {
        hl.RegWritePosEx(id, pos, speed, acc, currt_limit);
    }
}

void JointsCtrl::jsonSyncCtrlSMST(JsonArrayConst id, int idn, JsonArrayConst pos, JsonArrayConst spd, JsonArrayConst acc) {
    BusGuard busGuard;
    uint8_t  id_arr[idn];
    int16_t  pos_arr[idn];
    uint16_t spd_arr[idn];
    uint8_t  acc_arr[idn];
    for (int i = 0; i < idn; i++) {
        id_arr[i]  = id[i].as<uint8_t>();
        pos_arr[i] = pos[i].as<int16_t>();
        spd_arr[i] = spd[i].as<uint16_t>();
        acc_arr[i] = acc[i].as<uint8_t>();
    }
    smst.SyncWritePosEx(id_arr, idn, pos_arr, spd_arr, acc_arr);
}

void JointsCtrl::jsonSyncSimpleCtrlSMST(JsonArrayConst id, int idn, JsonArrayConst pos) {
    BusGuard busGuard;
    uint8_t  id_arr[idn];
    int16_t  pos_arr[idn];
    uint16_t spd_arr[idn];
    uint8_t  acc_arr[idn];
    for (int i = 0; i < idn; i++) {
        id_arr[i]  = id[i].as<uint8_t>();
        pos_arr[i] = pos[i].as<int16_t>();
        spd_arr[i] = 0;
        acc_arr[i] = 0;
    }
    smst.SyncWritePosEx(id_arr, idn, pos_arr, spd_arr, acc_arr);
}

void JointsCtrl::jsonSyncCtrlHL(JsonArrayConst id, int idn, JsonArrayConst pos, JsonArrayConst spd, JsonArrayConst acc, JsonArrayConst tor) {
    BusGuard busGuard;
    uint8_t  id_arr[idn];
    int16_t  pos_arr[idn];
    uint16_t spd_arr[idn];
    uint8_t  acc_arr[idn];
    uint16_t tor_arr[idn];
    for (int i = 0; i < idn; i++) {
        id_arr[i]  = id[i].as<uint8_t>();
        pos_arr[i] = pos[i].as<int16_t>();
        spd_arr[i] = spd[i].as<uint16_t>();
        acc_arr[i] = acc[i].as<uint8_t>();
        tor_arr[i] = tor[i].as<uint16_t>();
    }
    hl.SyncWritePosEx(id_arr, idn, pos_arr, spd_arr, acc_arr, tor_arr);
}

void JointsCtrl::jsonSyncSimpleCtrlHL(JsonArrayConst id, int idn, JsonArrayConst pos, JsonArrayConst tor) {
    BusGuard busGuard;
    uint8_t  id_arr[idn];
    int16_t  pos_arr[idn];
    uint16_t spd_arr[idn];
    uint8_t  acc_arr[idn];
    uint16_t tor_arr[idn];
    for (int i = 0; i < idn; i++) {
        id_arr[i]  = id[i].as<uint8_t>();
        pos_arr[i] = pos[i].as<int16_t>();
        spd_arr[i] = 60;
        acc_arr[i] = 50;
        tor_arr[i] = tor[i].as<uint16_t>();
    }
    hl.SyncWritePosEx(id_arr, idn, pos_arr, spd_arr, acc_arr, tor_arr);
}

void JointsCtrl::jsonSyncCtrlSC(JsonArrayConst id, int idn, JsonArrayConst pos, JsonArrayConst spd) {
    BusGuard busGuard;
    uint8_t  id_arr[idn];
    uint16_t  pos_arr[idn];
    uint16_t spd_arr[idn];
    for (int i = 0; i < idn; i++) {
        id_arr[i]  = id[i].as<uint8_t>();
        pos_arr[i] = pos[i].as<uint16_t>();
        spd_arr[i] = spd[i].as<uint16_t>();
    }
    sc.SyncWritePos(id_arr, idn, pos_arr, 0, spd_arr);
}

void JointsCtrl::jsonSyncSimpleCtrlSC(JsonArrayConst id, int idn, JsonArrayConst pos) {
    BusGuard busGuard;
    uint8_t  id_arr[idn];
    uint16_t  pos_arr[idn];
    uint16_t spd_arr[idn];
    for (int i = 0; i < idn; i++) {
        id_arr[i]  = id[i].as<uint8_t>();
        pos_arr[i] = pos[i].as<uint16_t>();
        spd_arr[i] = 0;
    }
    sc.SyncWritePos(id_arr, idn, pos_arr, 0, spd_arr);
}

double JointsCtrl::mapDouble(double x, double in_min, double in_max, double out_min, double out_max) {
    BusGuard busGuard;
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

int JointsCtrl::angleCtrlSC(u_int8_t id, int mid_pos, double angle, double speed, bool move_trigger) {
    BusGuard busGuard;
    int goal_pos = mid_pos + round(mapDouble(angle, 0, jointRangeAngle, 0, jointSteps));
    int goal_spd = round(mapDouble(speed, 0, jointRangeAngle, 0, jointSteps));
    if (move_trigger) {
        sc.WritePos(id, goal_pos, 0, goal_spd);
    } else {
        sc.RegWritePos(id, goal_pos, 0, goal_spd);
    }
    return goal_pos;
}

int JointsCtrl::angleCtrlSMST(u_int8_t id, double angle, double speed, double acc, bool move_trigger) {
    BusGuard busGuard;
    int goal_pos = middleSteps + round(mapDouble(angle, 0, jointRangeAngle, 0, jointSteps));
    int goal_spd = round(mapDouble(speed, 0, jointRangeAngle, 0, jointSteps));
    int goal_acc = round(mapDouble(acc, 0, jointRangeAngle, 0, jointSteps));
    if (move_trigger) {
        smst.WritePosEx(id, goal_pos, goal_spd, goal_acc);
    } else {
        smst.RegWritePosEx(id, goal_pos, goal_spd, goal_acc);
    }
    return goal_pos;
}

int JointsCtrl::angleCtrlHL(u_int8_t id, double angle, double speed, double acc, int currt_limit, bool move_trigger) {
    BusGuard busGuard;
    int goal_pos = middleSteps + round(mapDouble(angle, 0, jointRangeAngle, 0, jointSteps));
    int goal_spd = round(mapDouble(speed, 0, jointRangeAngle, 0, jointSteps));
    int goal_acc = round(mapDouble(acc, 0, jointRangeAngle, 0, jointSteps));
    if (move_trigger) {
        hl.WritePosEx(id, goal_pos, goal_spd, goal_acc, currt_limit);
    } else {
        hl.RegWritePosEx(id, goal_pos, goal_spd, goal_acc, currt_limit);
    }
    return goal_pos;
}

int JointsCtrl::radCtrlSC(u_int8_t id, int mid_pos, double rad, double speed, bool move_trigger) {
    BusGuard busGuard;
    int goal_pos = mid_pos + round(mapDouble(rad, 0, jointRangeRad, 0, jointSteps));
    int goal_spd = round(mapDouble(speed, 0, jointRangeRad, 0, jointSteps));
    if (move_trigger) {
        sc.WritePos(id, goal_pos, 0, goal_spd);
    } else {
        sc.RegWritePos(id, goal_pos, 0, goal_spd);
    }
    return goal_pos;
}

int JointsCtrl::radCtrlSMST(u_int8_t id, double rad, double speed, double acc, bool move_trigger) {
    BusGuard busGuard;
    int goal_pos = middleSteps + round(mapDouble(rad, 0, jointRangeRad, 0, jointSteps));
    int goal_spd = round(mapDouble(speed, 0, jointRangeRad, 0, jointSteps));
    int goal_acc = round(mapDouble(acc, 0, jointRangeRad, 0, jointSteps));
    if (move_trigger) {
        smst.WritePosEx(id, goal_pos, goal_spd, goal_acc);
    } else {
        smst.RegWritePosEx(id, goal_pos, goal_spd, goal_acc);
    }
    return goal_pos;
}

int JointsCtrl::radCtrlHL(u_int8_t id, double rad, double speed, double acc, int currt_limit, bool move_trigger) {
    BusGuard busGuard;
    int goal_pos = middleSteps + round(mapDouble(rad, 0, jointRangeRad, 0, jointSteps));
    int goal_spd = round(mapDouble(speed, 0, jointRangeRad, 0, jointSteps));
    int goal_acc = round(mapDouble(acc, 0, jointRangeRad, 0, jointSteps));
    if (move_trigger) {
        hl.WritePosEx(id, goal_pos, goal_spd, goal_acc, currt_limit);
    } else {
        hl.RegWritePosEx(id, goal_pos, goal_spd, goal_acc, currt_limit);
    }
    return goal_pos;
}

void JointsCtrl::moveTrigger() {
    BusGuard busGuard;
    switch (jointType) {
        case JOINT_TYPE_SC:
            sc.RegWriteAction();
            break;
        case JOINT_TYPE_SMST:
            smst.RegWriteAction();
            break;
        case JOINT_TYPE_HL:
            hl.RegWriteAction();
            break;
    }
}

// hub motor ctrl
void JointsCtrl::hubMotorCtrl(int spd_1, int spd_2, int spd_3, int spd_4) {
    BusGuard busGuard;
#ifdef USE_HUB_MOTORS
    gqdmd.SpeedCtl(1, spd_1, 500, 600, 0, 0x10);
    gqdmd.SpeedCtl(2, spd_2, 500, 600, 0, 0x10);
    gqdmd.SpeedCtl(3, spd_3, 500, 600, 0, 0x10);
    gqdmd.SpeedCtl(4, spd_4, 500, 600, 0, 0x10);
    gqdmd.StatusCtl(0, 2048);
#endif
}

// for applications: LyLinkArm
int* JointsCtrl::getJointsZeroPosArray() {
    BusGuard busGuard;
    return jointsZeroPos;
}

void JointsCtrl::setJointsZeroPosArray(int values[]) {
    BusGuard busGuard;
    for (int i = 0; i < JOINTS_NUM; i++) {
        jointsZeroPos[i] = values[i];
    }
}

int* JointsCtrl::getLinkArmPosSC() {
    BusGuard busGuard;
    for (int i = 0; i < JOINTS_NUM; i++) {
        jointsFeedbackPos[i] = sc.ReadPos(jointID[i]);
    }
    return jointsFeedbackPos;
}

void JointsCtrl::relativeStepsCtrl(int j0, int j1, int j2, int j3) {
    BusGuard busGuard;
    int j[JOINTS_NUM] = {j0, j1, j2, j3};
    for (int i = 0; i < JOINTS_NUM; i++) {
        stepsCtrlSC(jointID[i], jointsZeroPos[i] + j[i], 0, 0, false);
    }
    moveTrigger();
}

int* JointsCtrl::getRelativeSteps() {
    BusGuard busGuard;
    for (int i = 0; i < JOINTS_NUM; i++) {
        jointsRelativeSteps[i] = sc.ReadPos(jointID[i]) - jointsZeroPos[i];
    }
    return jointsRelativeSteps;
}

bool JointsCtrl::checkStatus() {
    BusGuard busGuard;
    for (int i = 0; i < JOINTS_NUM; i++) {
        jointsFeedbackPos[i] = sc.ReadPos(jointID[i]);
        if (jointsFeedbackPos[i] == -1) {
            return false;
        }
    }
    return true;
}

int* JointsCtrl::getLinkArmTorqueSC() {
    BusGuard busGuard;
    for (int i = 0; i < JOINTS_NUM; i++) {
        int load = sc.ReadLoad(jointID[i]);
        jointsFeedbackTorque[i] = (abs(load) < 1e-3) ? 0 : load;
    }
    return jointsFeedbackTorque;
}

void JointsCtrl::setCurrentSCPosMiddle() {
    BusGuard busGuard;
    for (int i = 0; i < JOINTS_NUM; i++) {
        jointsFeedbackPos[i] = sc.ReadPos(jointID[i]);
        jointsZeroPos[i] = jointsFeedbackPos[i];
    }
}

void JointsCtrl::setTorqueLimitSC(u_int8_t id, int limit) {
    BusGuard busGuard;
    limit = (limit < 0) ? 0 : (limit > 1000) ? 1000 : limit;
    sc.unLockEprom(id);
    sc.writeByte(id, 16, limit);
    sc.LockEprom(id);
}

// for applications: LyLinkArm
// joint_1 : as the base joint
// joint_2 : as the shoulder joint (base front)
// joint_3 : as the elbow joint (base back)
// joint_4 : as the gripper joint
// >-------O----O
// |       |   /
// 3       |  /
//       1-S E-2
//          B-0
void JointsCtrl::linkArmSCJointsCtrlAngle(double angles[]) {
    BusGuard busGuard;
    for (int i = 0; i < JOINTS_NUM; i++) {
        jointsCurrentPos[i] = angleCtrlSC(jointID[i], jointsZeroPos[i], angles[i], jointsMaxSpeed, false);
    }
    moveTrigger();
}

void JointsCtrl::linkArmSCJointsCtrlRad(double rads[]) {
    BusGuard busGuard;
    for (int i = 0; i < JOINTS_NUM; i++) {
        jointsCurrentPos[i] = radCtrlSC(jointID[i], jointsZeroPos[i], rads[i], jointsMaxSpeed, false);
    }
    moveTrigger();
}

bool JointsCtrl::linkArmPlaneIK(double x, double z) {
    BusGuard busGuard;
    // Calculate the angles for the joints based on the x and z coordinates
    double l_af = sqrt(pow(x, 2) + pow(z, 2));
    double theta = acos(- (pow(l_ab, 2) - pow(l_af, 2) - pow(l_bf, 2))/(2 * l_af * l_bf));
    double lambda = atan2(z, x);
    // output: the angle of the shoulder-front joint
    double alpha = 1.570796326794897 - theta - lambda;

    double omega = acos(-(pow(l_bf, 2) - pow(l_af, 2) - pow(l_ab, 2))/(2 * l_af * l_ab));
    double delta = atan2(x, z);
    // output: the radius of the eoat pitch
    double mu = delta + omega - 1.570796326794897;
    double l_ch = sin(mu) * l_ac;
    double l_ci = l_ch + z;
    double l_ah = cos(mu) * l_ac;
    double l_ei = x + l_ef - l_ah;
    double l_ce = sqrt(pow(l_ei, 2) + pow(l_ci, 2));
    double psi = acos(-(pow(l_cd, 2) - pow(l_ce, 2) - pow(l_de, 2))/(2 * l_ce * l_de));
    double epsilon = atan2(l_ci, l_ei);
    // output: the angle of the shoulder-rear joint
    double beta = epsilon + psi - 1.570796326794897;

    if (isnan(alpha) || isnan(beta) || isnan(theta)) {
        ik_status = false;
        return false;
    }
    ik_status = true;

    double armIKRad_1 = alpha - l_bf_rad;
    double armIKRad_2 = 1.570796326794897 - beta;

    if (armIKRad_1 >= jointMaxRads[1] || armIKRad_1 <= jointMinRads[1] ||
        armIKRad_2 >= jointMaxRads[2] || armIKRad_2 <= jointMinRads[2] ||
        mu >= jointMaxRads[3] || mu <= jointMinRads[3]) {
        ik_status = false;
        return false;
    }

    armIKRad[1] = armIKRad_1;
    armIKRad[2] = armIKRad_2;
    armIKRad[3] = mu;
    return true;
}

// use the xyzgIK to calculate the rbzgIK.
void JointsCtrl::spaceIK2FPVIK() {
    BusGuard busGuard;
    rbzgIK[0] = xyzgIK[0];
    rbzgIK[4] = xyzgIK[4];
    rbzgIK[2] = armIKRad[0];
    rbzgIK[1] = sqrt(pow(xyzgIK[1], 2) + pow(xyzgIK[2], 2)) - (l_ef / 2);
    rbzgIK[3] = xyzgIK[3];
}

// use the rbzgIK to calculate the xyzgIK.
void JointsCtrl::FPVIK2spaceIK() {
    BusGuard busGuard;
    xyzgIK[1] = rbzgIK[1] * cos(rbzgIK[2]) - (l_ef / 2);
    xyzgIK[2] = - rbzgIK[1] * sin(rbzgIK[2]);
    xyzgIK[3] = rbzgIK[3];
    xyzgIK[0] = rbzgIK[0];
    xyzgIK[4] = rbzgIK[4];
}

double* JointsCtrl::linkArmSpaceIK(double x, double y, double z, double g) {
    BusGuard busGuard;
    g = (g < GRIPPER_CLOSE) ? GRIPPER_CLOSE : (g > GRIPPER_OPEN) ? GRIPPER_OPEN : g;
    double armIKRad_0 = atan2(-y, x);
    if (armIKRad_0 >= jointMaxRads[1] || armIKRad_0 <= jointMinRads[1]) {
        xyzgIK[0] = -1;
        spaceIK2FPVIK();
        ik_status = false;
        return xyzgIK;
    }
    armIKRad[0] = armIKRad_0;
    linkArmPlaneIK(sqrt(pow(x, 2) + pow(y, 2)) - (l_ef / 2), z);
    if (ik_status) {
        radCtrlSC(jointID[0], jointsZeroPos[0], armIKRad[0], jointsMaxSpeed, false);
        radCtrlSC(jointID[1], jointsZeroPos[1], armIKRad[1], jointsMaxSpeed, false);
        radCtrlSC(jointID[2], jointsZeroPos[2], armIKRad[2], jointsMaxSpeed, false);
        angleCtrlSC(jointID[3], jointsZeroPos[3], g, 0, false);
        moveTrigger();
        xyzgIK[0] = 1;
        xyzgIK[1] = x;
        xyzgIK[2] = y;
        xyzgIK[3] = z;
        xyzgIK[4] = g;
        spaceIK2FPVIK();
        return xyzgIK;
    } else {
        xyzgIK[0] = -1;
        spaceIK2FPVIK();
        return xyzgIK;
    }
}

double* JointsCtrl::linkArmFPVIK(double r, double b, double z, double g) {
    BusGuard busGuard;
    g = (g < GRIPPER_CLOSE) ? GRIPPER_CLOSE : (g > GRIPPER_OPEN) ? GRIPPER_OPEN : g;
    if (b >= jointMaxRads[1] || b <= jointMinRads[1]) {
        rbzgIK[0] = -1;
        FPVIK2spaceIK();
        ik_status = false;
        return rbzgIK;
    }
    armIKRad[0] = b;
    linkArmPlaneIK(r - (l_ef / 2), z);
    if (ik_status) {
        radCtrlSC(jointID[0], jointsZeroPos[0], armIKRad[0], jointsMaxSpeed, false);
        radCtrlSC(jointID[1], jointsZeroPos[1], armIKRad[1], jointsMaxSpeed, false);
        radCtrlSC(jointID[2], jointsZeroPos[2], armIKRad[2], jointsMaxSpeed, false);
        angleCtrlSC(jointID[3], jointsZeroPos[3], g, 0, false);
        moveTrigger();
        rbzgIK[0] = 1;
        rbzgIK[1] = r;
        rbzgIK[2] = b;
        rbzgIK[3] = z;
        rbzgIK[4] = g;
        FPVIK2spaceIK();
        return rbzgIK;
    } else {
        rbzgIK[0] = -1;
        FPVIK2spaceIK();
        return rbzgIK;
    }
}

// ctrl the movement in a smooth way.
// |                 ..  <-end
// |             .    |
// |           .    
// |         .        |
// |        .
// |      .           |
// |. . <-start
// ----------------------
// 0                  1 rate
double JointsCtrl::smoothCtrl(double start, double end, double rate) {
    BusGuard busGuard;
    double out;
    out = (end - start)*((cos(rate*M_PI+M_PI)+1)/2) + start;
    return out;
}

double JointsCtrl::getSmoothStepsXYZ(double x, double y, double z) {
    BusGuard busGuard;
    double deltaPos[3] = {abs(x - xyzgIK_last[1]),
                          abs(y - xyzgIK_last[2]),
                          abs(z - xyzgIK_last[3])};
    double maxVal = deltaPos[0];
    for(int i = 0; i < (sizeof(deltaPos) / sizeof(deltaPos[0])); i++){
      maxVal = max(deltaPos[i],maxVal);
    }
    return maxVal;
}

double* JointsCtrl::smoothXYZGCtrl(double x, double y, double z, double g, double spd) {
    BusGuard busGuard;
    memcpy(xyzgIK_last, xyzgIK, sizeof(xyzgIK));
    for (double i=0; i<=1; i+=(spd/getSmoothStepsXYZ(x, y, z))) {
        linkArmSpaceIK(smoothCtrl(xyzgIK_last[1], x, i), 
                       smoothCtrl(xyzgIK_last[2], y, i), 
                       smoothCtrl(xyzgIK_last[3], z, i), 
                       g);
        if (xyzgIK[0] == -1) {
            memcpy(xyzgIK_last, xyzgIK, sizeof(xyzgIK));
            return xyzgIK;
        }
    }
    linkArmSpaceIK(x, y, z, g);
    memcpy(xyzgIK_last, xyzgIK, sizeof(xyzgIK));
    return xyzgIK;
}

double JointsCtrl::getSmoothStepsFPV(double r, double b, double z, double baseRate) {
    BusGuard busGuard;
    double deltaPos[3] = {abs(r - rbzgIK_last[1]),
                          abs(b - rbzgIK_last[2]) * baseRate,
                          abs(z - rbzgIK_last[3])};
    double maxVal = deltaPos[0];
    for(int i = 0; i < (sizeof(deltaPos) / sizeof(deltaPos[0])); i++){
      maxVal = max(deltaPos[i],maxVal);
    }
    return maxVal;
}

double* JointsCtrl::smoothFPVAbsCtrl(double r, double b, double z, double g, double spd, double baseRate) {
    BusGuard busGuard;
    memcpy(rbzgIK_last, rbzgIK, sizeof(rbzgIK));
    for (double i=0; i<=1; i+=(spd/getSmoothStepsFPV(r, b, z, baseRate))) {
        linkArmFPVIK(smoothCtrl(rbzgIK_last[1], r, i), 
                     smoothCtrl(rbzgIK_last[2], b, i), 
                     smoothCtrl(rbzgIK_last[3], z, i), 
                     g);
        if (rbzgIK[0] == -1) {
            memcpy(rbzgIK_last, rbzgIK, sizeof(rbzgIK));
            return rbzgIK;
        }
    }
    linkArmFPVIK(r, b, z, g);
    memcpy(rbzgIK_last, rbzgIK, sizeof(rbzgIK));
    return rbzgIK;
}

void JointsCtrl::setMaxJointsSpeed(double speed) {
    BusGuard busGuard;
    if (speed >= 0) {
        jointsMaxSpeed = speed;
    }
}

double* JointsCtrl::getJointFBRads() {
    BusGuard busGuard;
    static double jointRads[JOINTS_NUM];
    getLinkArmPosSC();
    for (int i = 0; i < JOINTS_NUM; i++) {
        jointRads[i] = mapDouble(jointsFeedbackPos[i] - jointsZeroPos[i], 0, jointSteps, 0, jointRangeRad) * jointDirection[i];
    }
    return jointRads;
}

double* JointsCtrl::getJointGoalRads() {
    BusGuard busGuard;
    return armIKRad;
}

double* JointsCtrl::getXYZGIK() {
    BusGuard busGuard;
    return xyzgIK;
}

double* JointsCtrl::getRBZGIK() {
    BusGuard busGuard;
    return rbzgIK;
}

void JointsCtrl::setLinkArmFeedbackFlag(bool flag, int hz) {
    BusGuard busGuard;
    linkArmFeedbackFlag = flag;
    linkArmFeedbackHz = hz;
}

bool JointsCtrl::linkArmPlaneFK(double alpha, double beta, double& x, double& z) {
    BusGuard busGuard;
    // Calculate the forward kinematics based on the joint angles alpha and beta
    double theta = 1.570796326794897 - alpha; // Recover theta from alpha
    double lambda = 1.570796326794897 - beta; // Recover lambda from beta

    // Calculate the length of l_af using the angles
    double l_af = sqrt(pow(l_ab, 2) + pow(l_bf, 2) - 2 * l_ab * l_bf * cos(theta));

    // Calculate the angle delta
    double delta = acos((pow(l_af, 2) + pow(l_ab, 2) - pow(l_bf, 2)) / (2 * l_af * l_ab));

    // Calculate the x and z coordinates
    x = l_af * cos(lambda + delta);
    z = l_af * sin(lambda + delta);

    // Check for invalid results
    if (isnan(x) || isnan(z)) {
        ik_status = false;
        return false;
    }

    ik_status = true;
    return true;
}

bool JointsCtrl::constantCtrl(bool flag, int axis, double delta) {
    BusGuard busGuard;
    constantCtrlFlag = flag;
    constantCtrlAxis = axis;
    constantCtrldDelta = delta;
    return true;
}

void JointsCtrl::constantCtrlLoop() {
    BusGuard busGuard;
    if (!constantCtrlFlag) {
        return;
    } else if (constantCtrlFlag) {
        switch(constantCtrlAxis) {
            case -1: return; break;

            case  1: 
                    cart_x = xyzgIK[1] + constantCtrldDelta;
                    linkArmSpaceIK(cart_x, xyzgIK[2], xyzgIK[3], xyzgIK[4]);
                    break;
            case  2:
                    cart_y = xyzgIK[2] + constantCtrldDelta;
                    linkArmSpaceIK(xyzgIK[1], cart_y, xyzgIK[3], xyzgIK[4]);
                    break;
            case  3:
                    cart_z = xyzgIK[3] + constantCtrldDelta;
                    linkArmSpaceIK(xyzgIK[1], xyzgIK[2], cart_z, xyzgIK[4]);
                    break;
            case  4:
                    cart_g = xyzgIK[4] + constantCtrldDelta;
                    linkArmSpaceIK(xyzgIK[1], xyzgIK[2], xyzgIK[3], cart_g);
                    break;

            case  11: 
                    fpv_r = rbzgIK[1] + constantCtrldDelta;
                    linkArmFPVIK(fpv_r, rbzgIK[2], rbzgIK[3], rbzgIK[4]);
                    break;
            case  12:
                    fpv_b = rbzgIK[2] + constantCtrldDelta;
                    linkArmFPVIK(rbzgIK[1], fpv_b, rbzgIK[3], rbzgIK[4]);
                    break;
            case  13:
                    fpv_z = rbzgIK[3] + constantCtrldDelta;
                    linkArmFPVIK(rbzgIK[1], rbzgIK[2], fpv_z, rbzgIK[4]);
                    break;
            case  14:
                    fpv_g = rbzgIK[4] + constantCtrldDelta;
                    linkArmFPVIK(rbzgIK[1], rbzgIK[2], rbzgIK[3], fpv_g);
                    break;
        }
    }

}

void JointsCtrl::ttlTestMachine() {
    BusGuard busGuard;
    while (true)
    {
        stepsCtrlSC(254, 200, 0, 0, 1);
        delay(1000);
        stepsCtrlSC(254, 900, 0, 0, 1);
        delay(1000);
    }
    
}

// TTL Node
int JointsCtrl::writeByte(u_int8_t id, u_int8_t addr, u8 data) {
    BusGuard busGuard;
    return smst.writeByte(id, addr, data);
}

void JointsCtrl::singleLedCtrl(u_int8_t id, u_int8_t num, u_int8_t r, u_int8_t g, u_int8_t b) {
    BusGuard busGuard;
    uint8_t r2 = (r * 4) / 256;
    uint8_t g3 = (g * 8) / 256;
    uint8_t b2 = (b * 4) / 256;

    uint8_t rgb232 = ((g3 << 5) | (r2 << 2) | b2) << 1;

    if (num == 1) {
        smst.writeByte(id, 43, rgb232);
    } else if (num == 2)
    {
        smst.writeByte(id, 44, rgb232);
    }
    smst.writeByte(id, 42, 2);
}

void JointsCtrl::allLedCtrl(u_int8_t id, u_int8_t r, u_int8_t g, u_int8_t b) {
    BusGuard busGuard;
    uint8_t r2 = (r * 4) / 256;
    uint8_t g3 = (g * 8) / 256;
    uint8_t b2 = (b * 4) / 256;

    uint8_t rgb232 = ((g3 << 5) | (r2 << 2) | b2) << 1;

    smst.writeByte(id, 43, rgb232);
    smst.writeByte(id, 44, rgb232);
    smst.writeByte(id, 42, 2);
}

int JointsCtrl::readSBUS() {
    BusGuard busGuard;
    if(node.sbusFlush(0)){
        sbus[0] = node.sbusStatus();//subs status
        for(int ch=1; ch<=node.subsGetNum(); ch++){
            sbus[ch] = node.sbusGetch(ch);
        }
    }else{
        return -1;
    }
    return sbus[0];
}

void JointsCtrl::ttlnChangeID(u_int8_t old_id, u_int8_t new_id) {
    BusGuard busGuard;
    node.unLockEprom(old_id);
    node.writeByte(old_id, LY_NODE_ID, new_id);
    node.LockEprom(new_id);
}

void JointsCtrl::ttlnCtrlPWM(u_int8_t node_id, int pwm_ch, int pwm_val) {
    BusGuard busGuard;
    node.pwmCtl(node_id, pwm_ch, pwm_val);
}

void JointsCtrl::ttlnCtrlSingleLed(u_int8_t node_id, int rgb_ch, int r, int g, int b) {
    BusGuard busGuard;
    node.ledSingleCtrl(node_id, rgb_ch, g, r, b);//node_id, rgb_ch, r, g, b
}

void JointsCtrl::ttlnLedFlush(u_int8_t node_id, int led_num) {
    BusGuard busGuard;
    node.ledFlush(node_id, led_num);
}

void JointsCtrl::ttlnCtrlAllLed(u_int8_t node_id, int led_num, int r, int g, int b) {
    BusGuard busGuard;
    node.ledAllCtrl(node_id, led_num, g, r, b);
}
