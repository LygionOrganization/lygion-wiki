Lyo-D42 0.4.0 release candidate (not hardware qualified)
ESP32-S3, 8 MB flash. Use these offsets in the ESP32-S3 flash tool:
bootloader.bin 0x0
partitions.bin 0x8000
firmware.bin 0x10000
Never write firmware.bin at 0x0. Disconnect motor power during recovery.
Erasing flash removes saved network settings, chassis settings and missions.
After recovery query state first, then test low-speed operation with wheels raised.
See the matching source package docs/RELEASE_VALIDATION.md and docs/UPSTREAM.md.
Licenses: project GPLv3 (LICENSE), inherited RoboCore AGPLv3 (LICENSE-AGPL).
Retain individual library notices from the matching source distribution.
