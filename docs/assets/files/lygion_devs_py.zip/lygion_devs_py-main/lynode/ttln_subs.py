#!/usr/bin/env python
#
# *********     Gen Write Example      *********
#
#
# Available lydevs model on this example : All models using Protocol SCS
# This example is tested with a lydevs(node)
#

import sys
import os
import time

sys.path.append("..")
from lydevs_sdk import *                      # Uses lydevs SDK library


# Initialize PortHandler instance
# Set the port path
# Get methods and members of PortHandlerLinux or PortHandlerWindows
portHandler = PortHandler('/dev/ttyUSB0')# ex) Windows: "COM1"   Linux: "/dev/ttyUSB0" Mac: "/dev/tty.usbserial-*"

# Initialize PacketHandler instance
# Get methods and members of Protocol
packetHandler = NodeClass(portHandler)
    
# Open port
if portHandler.openPort():
    print("Succeeded to open the port")
else:
    print("Failed to open the port")
    quit()

# Set port baudrate 1000000
if portHandler.setBaudRate(1000000):
    print("Succeeded to change the baudrate")
else:
    print("Failed to change the baudrate")
    quit()

while 1:
    # node_id=1, read subs buf
    scs_comm_result, scs_error = packetHandler.sbusFlush(1)
    if scs_comm_result != COMM_SUCCESS:
        print("%s" % packetHandler.getTxRxResult(scs_comm_result))
    elif scs_error != 0:
        print("%s" % packetHandler.getRxPacketError(scs_error))
    else :
        print("status:{}".format(packetHandler.sbusStatus()))
        for ch in range(1, packetHandler.subsGetNum() + 1):
            print("ch{}:{}".format(ch, packetHandler.sbusGetch(ch)))
        print('---------------')
        time.sleep(0.3)

# Close port
portHandler.closePort()
