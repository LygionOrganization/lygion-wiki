## Structure

```
root dirrectory
     |---lynode 
     |---lyttlsd
```
The 'lynode ' 'lyttlsd' directories contain examples of using the library.

The source code of the library is located in the `lydevs_sdk` directory.

The 'lydevs_sdk' directory contains the original archive with the source code of the library from the developer.

## Usage

Tested on Linux Raspbian GNU/Linux 9.13 (stretch).
Python version Python 3.5.3

### Method 1. Clone repositry

```
$ cd /usr/src/
$ sudo git clone https://github.com/gjwmotor/lygion_devs_py.git
$ sudo chown -R pi lygion_devs_py
$ cd lygion_devs_py/lynode
$ python3 ttln_ping.py
Succeeded to open the port
Succeeded to change the baudrate
[ID:001] ping Succeeded. lydevs model number : 
```

