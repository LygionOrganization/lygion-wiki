RoboCore S3 firmware
Restore the RoboCore S3 web console and JSON control firmware.
Use the existing ESP32-S3 Flash Download Tool with these three files from this archive:
bootloader.bin  0x0
partitions.bin  0x8000
firmware.bin    0x10000
Flash size: 8MB. Do not write firmware.bin at 0x0.
Disconnect actuators/motor power before recovery. Erasing flash removes saved settings and missions.
See the RoboCore S3 wiki firmware recovery tutorial for boot mode and tool instructions.
