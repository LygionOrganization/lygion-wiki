// BEGIN EXAMPLE SETUP
// Board package: esp32 by Espressif Systems 3.3.0 (Boards Manager).
// Console: UART0 / Serial0 at 115200 baud through the Type-C UART port.
// Keep the upload cable connected to Type-C UART for feedback and commands.
// Recommended Arduino setting: USB CDC On Boot = Disabled.
// Serial0 explicitly selects UART0 even if USB CDC On Boot is enabled.
// Bundled library: copy the entire lib/RoboCoreSupport folder from this project
// to your Arduino sketchbook libraries/RoboCoreSupport folder, then restart the IDE.
// Other ESP32 headers (Arduino, Wire, WiFi, USB, drivers, FreeRTOS) come with the board package.
// PlatformIO: put bundled libraries in lib/ and install external libraries via lib_deps.
// END EXAMPLE SETUP
#include <Arduino.h>
#include <Wire.h>
#include <OptionalQMI8658.h>
OptionalQMI8658 imu;
void setup() {
  Serial0.begin(115200);
  Wire.begin(6, 7);
  Wire.setClock(400000);
  Wire.setTimeOut(20);
  if (!imu.begin(Wire)) Serial0.println("Onboard QMI8658A unavailable; check the shared I2C bus.");
}
void loop() {
  OptionalQMI8658::Sample s;
  if (imu.sample(s)) {
    Serial0.printf("a[g]=%.3f,%.3f,%.3f g[dps]=%.3f,%.3f,%.3f T[C]=%.2f\n",
                  s.ax,s.ay,s.az,s.gx,s.gy,s.gz,s.temperature);
  }
  delay(100);
}
